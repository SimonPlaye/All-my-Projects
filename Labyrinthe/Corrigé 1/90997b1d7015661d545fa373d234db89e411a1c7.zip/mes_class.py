# -*- coding=utf8 -*

class class_joueur ():

    def __init__(self, pseudo="", score = 0, cec = "") :
        self.pseudo = pseudo
        self.score = score
        self.carte_en_cour = cec
